import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../shared/services/auth'; // adjust path as needed

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './header.html',
  styleUrls: ['./header.css']
})
export class Header {
  authService = inject(AuthService);
  router = inject(Router);

  isLoggedIn = false;
  role: string | null = null;

  ngOnInit(): void {
    this.isLoggedIn = this.authService.isLoggedIn();
    this.role = this.authService.getUserRoles(); // 'User' or 'ServiceCenter'
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/']);
  }
}