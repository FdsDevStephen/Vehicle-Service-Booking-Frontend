import { Component, OnInit, inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../../shared/services/auth';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-registration',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './registration.html',
})
export class Register implements OnInit {
  form: FormGroup;
  isSubmitted = false;

  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private toastr = inject(ToastrService);
  private router = inject(Router);

  constructor() {
    this.form = this.fb.group(
      {
        fullName: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        password: [
          '',
          [
            Validators.required,
            Validators.minLength(8),
            Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*]).{8,}$'),
          ],
        ],
        confirmPassword: ['', Validators.required],
        phoneNumber: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
        address: ['', Validators.required],
        role: ['', Validators.required],
        serviceCenterName: [''],
        serviceCenterLocation: [''],
        serviceCenterContact: [''],
      },
      { validators: this.passwordMatchValidator }
    );
  }

  ngOnInit(): void {
    this.form.get('role')?.valueChanges.subscribe((role) => {
      this.updateValidatorsBasedOnRole(role);
    });
  }

  passwordMatchValidator(group: FormGroup) {
    const password = group.get('password')?.value;
    const confirm = group.get('confirmPassword')?.value;
    return password === confirm ? null : group.get('confirmPassword')?.setErrors({ mismatch: true });
  }

  updateValidatorsBasedOnRole(role: string): void {
    const name = this.form.get('serviceCenterName');
    const loc = this.form.get('serviceCenterLocation');
    const contact = this.form.get('serviceCenterContact');

    if (role === 'ServiceCenter') {
      name?.setValidators([Validators.required]);
      loc?.setValidators([Validators.required]);
      contact?.setValidators([Validators.required]);
    } else {
      name?.clearValidators();
      loc?.clearValidators();
      contact?.clearValidators();
    }

    name?.updateValueAndValidity();
    loc?.updateValueAndValidity();
    contact?.updateValueAndValidity();
  }

  onSubmit(): void {
    this.isSubmitted = true;
    if (this.form.invalid) {
      this.toastr.error('Please correct the form fields.', 'Validation Error');
      return;
    }

    console.log('Form Values:', this.form.value); // Debugging line

    this.authService.createUser(this.form.value).subscribe({
      next: () => {
        this.toastr.success('Registration successful!', 'Success');
        this.router.navigate(['/login']);
      },
      error: (err) => {
        console.error(err);

        if (err.error === 'Invalid role') {
          this.toastr.error('The selected role is invalid. Please choose a valid role.', 'Error');
        } else if (typeof err.error === 'string') {
          this.toastr.error(err.error, 'Error');
        } else if (err.error && err.error.errors) {
          const messages = Object.values(err.error.errors).flat() as string[];
          messages.forEach((msg) => this.toastr.error(msg, 'Validation Error'));
        } else {
          this.toastr.error('Registration failed. Please try again.', 'Error');
        }
      },
    });
  }
}