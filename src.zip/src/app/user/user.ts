import { Component } from '@angular/core';
import { Login } from "./login/login";
// import { Registration } from "./registration/registration"; // Keep Login if you're using <app-login>
// Remove Registration if it's commented out in your template or not used
// import { Registration } from "./registration/registration"; // <--- Remove or comment out this line

@Component({
  selector: 'app-user',
  standalone: true,
  imports: [ Login], // <--- Only import Login here if Registration isn't used
  templateUrl: './user.html',
  styles: ``
})
export class User {

}