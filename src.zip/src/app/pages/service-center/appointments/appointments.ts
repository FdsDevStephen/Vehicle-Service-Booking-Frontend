import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ServiceCenterAppointmentsService } from '../../../shared/services/appointment.service';

@Component({
  selector: 'app-appointments',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './appointments.html',
})
export class AppointmentsComponent {
  appointments: any[] = [];
  isLoading = false; // Add isLoading property
  errorMessage: string | null = null; // Add errorMessage property

  constructor(private appointmentService: ServiceCenterAppointmentsService) {}

  ngOnInit(): void {
    this.loadAppointments();
  }

  loadAppointments(): void {
    this.isLoading = true; // Set loading state
    this.errorMessage = null; // Clear any previous error messages
  
    this.appointmentService.getAppointments().subscribe({
      next: (res) => {
        console.log('Appointments:', res); // Debugging line
        this.appointments = res;
        this.isLoading = false; // Reset loading state
      },
      error: (err) => {
        console.error('Failed to load appointments', err);
        this.errorMessage = 'Failed to load appointments. Please try again later.';
        this.isLoading = false; // Reset loading state
      },
    });
  }

  markAsCompleted(appointmentId: number): void {
    console.log('Marking appointment as completed. ID:', appointmentId); // Debugging line
    this.isLoading = true; // Set loading state during update
    this.appointmentService.updateBookingStatus(appointmentId, 'Completed').subscribe({
      next: () => {
        this.loadAppointments(); // Reload appointments to reflect the updated status
      },
      error: (err) => {
        console.error('Failed to update status', err);
        this.errorMessage = 'Failed to update status. Please try again later.';
        this.isLoading = false; // Reset loading state
      },
    });
  }
}