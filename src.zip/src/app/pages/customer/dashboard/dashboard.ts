import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
// import { Header } from '../../../shared/header/header';
// import { Footer } from '../../../shared/footer/footer';

// , Header, Footer

@Component({
  selector: 'app-user-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],  
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.css']
})
export class UserDashboard implements OnInit {
  userName = 'Stephen'; // To fetch from token later
  greeting: string = '';

  // vehicles = [
  //   { name: 'Honda Activa', type: 'Scooter', nextService: '22/06/2024' },
  //   { name: 'Royal Enfield', type: 'Bike', nextService: '31/07/2024' },
  //   { name: 'Hyundai Tucson', type: 'Car', nextService: '26/06/2024' }
  // ];

  ngOnInit(): void {
    const hour = new Date().getHours();
    this.greeting = hour < 12 ? 'Good Morning' : hour < 17 ? 'Good Afternoon' : 'Good Evening';
  }
}
