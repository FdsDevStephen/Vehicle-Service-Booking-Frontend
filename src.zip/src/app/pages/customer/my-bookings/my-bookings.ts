import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BookingService } from '../../../shared/services/booking.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-my-bookings',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './my-bookings.html',
  styleUrls: ['./my-bookings.css']
})
export class MyBookings implements OnInit {
  private bookingService = inject(BookingService);
  private toastr = inject(ToastrService);

  bookings: any[] = [];

  ngOnInit(): void {
    this.fetchBookings();
  }

  fetchBookings(): void {
    this.bookingService.getUserBookings().subscribe({
      next: (res) => this.bookings = res,
      error: (err) => {
        console.error('Failed to fetch bookings', err);
        this.toastr.error('Could not load bookings');
      }
    });
  }

  cancelBooking(bookingId: number): void {
    const confirmCancel = confirm('Are you sure you want to cancel this booking?');
    if (!confirmCancel) return;

    this.bookingService.updateBookingStatus(bookingId, 'Cancelled').subscribe({
      next: () => {
        this.toastr.success('Booking cancelled successfully');
        // Optionally update only the status without full reload:
        this.bookings = this.bookings.map(b =>
          b.bookingId === bookingId ? { ...b, serviceStatus: 'Cancelled' } : b
        );
      },
      error: (err) => {
        console.error('Failed to cancel booking', err);
        this.toastr.error('Could not cancel the booking');
      }
    });
  }
}
