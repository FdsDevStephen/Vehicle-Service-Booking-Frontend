import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VehicleService } from '../../../shared/services/vehicle.service';
import { ServiceCenterService } from '../../../shared/services/service-center.service';
import { ServiceTypeService } from '../../../shared/services/service-type.service';
import { BookingService } from '../../../shared/services/booking.service';

import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-book-service',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './book-service.html',
  styleUrl: './book-service.css'
})
export class BookService implements OnInit {
  // Inject services
  private vehicleService = inject(VehicleService);
  private serviceCenterService = inject(ServiceCenterService);
  private serviceTypeService = inject(ServiceTypeService);
  private bookingService = inject(BookingService);
  private toastr = inject(ToastrService);

  // Form model
  serviceBooking = {
    vehicleId: '',
    serviceCenterId: '',
    serviceTypeId: '',
    date: '',
    time: ''
  };

  // Dropdown data
  vehicles: any[] = [];
  serviceCenters: any[] = [];
  serviceTypes: any[] = [];
  minDate: string = '';
  ngOnInit(): void {
    this.loadVehicles();
    this.loadServiceCenters();
    this.loadServiceTypes();
    const today = new Date();
    this.minDate = today.toISOString().split('T')[0]; // format YYYY-MM-DD
  }

  loadVehicles() {
    this.vehicleService.getUserVehicles().subscribe({
      next: (res) => {
        console.log('Vehicles:', res);
        this.vehicles = res;
      },
      error: (err) => console.error('Failed to load vehicles', err)
    });
  }

  loadServiceCenters() {
    this.serviceCenterService.getAllServiceCenters().subscribe({
      next: (res) => {
        console.log('Service Centers:', res);
        this.serviceCenters = res;
      },
      error: (err) => console.error('Failed to load service centers', err)
    });
  }

  loadServiceTypes() {
    this.serviceTypeService.getAllServiceTypes().subscribe({
      next: (res) => {
        console.log('Service Types:', res); // Debugging line
        this.serviceTypes = res;
      },
      error: (err) => console.error('Failed to load service types', err)
    });
  }



  onSubmit() {
    console.log('Raw form values:', this.serviceBooking); // Debugging line

    const vehicleId = +this.serviceBooking.vehicleId;
    const serviceCenterId = +this.serviceBooking.serviceCenterId;
    const serviceTypeId = +this.serviceBooking.serviceTypeId;
    const date = this.serviceBooking.date;
    const time = this.serviceBooking.time;

    if (!vehicleId || !serviceCenterId || !serviceTypeId || !date || !time) {
      this.toastr.error('Please fill all fields correctly.', 'Validation Error');
      return;
    }

    const payload = {
      vehicleId,
      serviceCenterId,
      serviceTypeId,
      date,
      timeSlot: time
    };

    console.log('Final booking payload:', payload);

    this.bookingService.createBooking(payload).subscribe({
      next: (res) => {
        console.log('Booking response:', res); // Debugging line
        this.toastr.success(res, 'Success'); // Display the plain text response
      },
      error: (err) => {
        console.error('Booking failed', err);
        this.toastr.error('Failed to book service. Please try again.', 'Error');
      }
    });
  }


}
